--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.0
-- Dumped by pg_dump version 14.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1252';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: nm_ccnpm; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA nm_ccnpm;


ALTER SCHEMA nm_ccnpm OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dinh_chinh; Type: TABLE; Schema: nm_ccnpm; Owner: postgres
--

CREATE TABLE nm_ccnpm.dinh_chinh (
    "ID" integer NOT NULL,
    "idHoKhau" integer NOT NULL,
    "thongTinThayDoi" character varying NOT NULL,
    "thayDoiTu" character varying NOT NULL,
    "doiThanh" character varying NOT NULL,
    "ngayThayDoi" date NOT NULL,
    "nguoiThayDoi" integer NOT NULL
);


ALTER TABLE nm_ccnpm.dinh_chinh OWNER TO postgres;

--
-- Name: dinh_chinh_ID_seq; Type: SEQUENCE; Schema: nm_ccnpm; Owner: postgres
--

CREATE SEQUENCE nm_ccnpm."dinh_chinh_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE nm_ccnpm."dinh_chinh_ID_seq" OWNER TO postgres;

--
-- Name: dinh_chinh_ID_seq; Type: SEQUENCE OWNED BY; Schema: nm_ccnpm; Owner: postgres
--

ALTER SEQUENCE nm_ccnpm."dinh_chinh_ID_seq" OWNED BY nm_ccnpm.dinh_chinh."ID";


--
-- Name: dinh_danh; Type: TABLE; Schema: nm_ccnpm; Owner: postgres
--

CREATE TABLE nm_ccnpm.dinh_danh (
    "ID" integer NOT NULL,
    "idNhanKhau" integer NOT NULL,
    "soDinhDanh" character varying(20) NOT NULL,
    "ngayCap" date NOT NULL,
    "noiCap" character varying(100) NOT NULL,
    type character varying(30) NOT NULL
);


ALTER TABLE nm_ccnpm.dinh_danh OWNER TO postgres;

--
-- Name: dinh_danh_ID_seq; Type: SEQUENCE; Schema: nm_ccnpm; Owner: postgres
--

CREATE SEQUENCE nm_ccnpm."dinh_danh_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE nm_ccnpm."dinh_danh_ID_seq" OWNER TO postgres;

--
-- Name: dinh_danh_ID_seq; Type: SEQUENCE OWNED BY; Schema: nm_ccnpm; Owner: postgres
--

ALTER SEQUENCE nm_ccnpm."dinh_danh_ID_seq" OWNED BY nm_ccnpm.dinh_danh."ID";


--
-- Name: dong_gop; Type: TABLE; Schema: nm_ccnpm; Owner: postgres
--

CREATE TABLE nm_ccnpm.dong_gop (
    "ID" integer NOT NULL,
    "tenKhoanDong" character varying(100) NOT NULL,
    "ngayTao" date NOT NULL,
    "soTien" integer NOT NULL,
    "donVi" character varying(100) NOT NULL,
    "theLoai" character varying(100) NOT NULL,
    "hoanThanh" boolean NOT NULL
);


ALTER TABLE nm_ccnpm.dong_gop OWNER TO postgres;

--
-- Name: dong_gop_ID_seq; Type: SEQUENCE; Schema: nm_ccnpm; Owner: postgres
--

CREATE SEQUENCE nm_ccnpm."dong_gop_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE nm_ccnpm."dong_gop_ID_seq" OWNER TO postgres;

--
-- Name: dong_gop_ID_seq; Type: SEQUENCE OWNED BY; Schema: nm_ccnpm; Owner: postgres
--

ALTER SEQUENCE nm_ccnpm."dong_gop_ID_seq" OWNED BY nm_ccnpm.dong_gop."ID";


--
-- Name: ho_khau; Type: TABLE; Schema: nm_ccnpm; Owner: postgres
--

CREATE TABLE nm_ccnpm.ho_khau (
    "ID" integer NOT NULL,
    "idChuHo" integer,
    "maKhuVuc" character varying(100) NOT NULL,
    "diaChi" character varying(100) NOT NULL,
    "ngayChuyenDi" date NOT NULL,
    "daXoa" boolean DEFAULT true NOT NULL,
    "maHoKhau" character varying(30) NOT NULL
);


ALTER TABLE nm_ccnpm.ho_khau OWNER TO postgres;

--
-- Name: ho_khau_ID_seq; Type: SEQUENCE; Schema: nm_ccnpm; Owner: postgres
--

CREATE SEQUENCE nm_ccnpm."ho_khau_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE nm_ccnpm."ho_khau_ID_seq" OWNER TO postgres;

--
-- Name: ho_khau_ID_seq; Type: SEQUENCE OWNED BY; Schema: nm_ccnpm; Owner: postgres
--

ALTER SEQUENCE nm_ccnpm."ho_khau_ID_seq" OWNED BY nm_ccnpm.ho_khau."ID";


--
-- Name: ho_khau_dong_gop; Type: TABLE; Schema: nm_ccnpm; Owner: postgres
--

CREATE TABLE nm_ccnpm.ho_khau_dong_gop (
    "idHoKhau" integer NOT NULL,
    "daDong" integer NOT NULL,
    "ngayDong" date NOT NULL,
    "idDongGop" integer NOT NULL
);


ALTER TABLE nm_ccnpm.ho_khau_dong_gop OWNER TO postgres;

--
-- Name: khai_tu; Type: TABLE; Schema: nm_ccnpm; Owner: postgres
--

CREATE TABLE nm_ccnpm.khai_tu (
    "ID" integer NOT NULL,
    "soGiayKhaiTu" character varying(100) NOT NULL,
    "idNguoiKhai" integer NOT NULL,
    "idNguoiChet" integer NOT NULL,
    "ngayKhai" date NOT NULL,
    "ngayChet" date NOT NULL,
    "lyDoChet" character varying(100) NOT NULL
);


ALTER TABLE nm_ccnpm.khai_tu OWNER TO postgres;

--
-- Name: khai_tu_ID_seq; Type: SEQUENCE; Schema: nm_ccnpm; Owner: postgres
--

CREATE SEQUENCE nm_ccnpm."khai_tu_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE nm_ccnpm."khai_tu_ID_seq" OWNER TO postgres;

--
-- Name: khai_tu_ID_seq; Type: SEQUENCE OWNED BY; Schema: nm_ccnpm; Owner: postgres
--

ALTER SEQUENCE nm_ccnpm."khai_tu_ID_seq" OWNED BY nm_ccnpm.khai_tu."ID";


--
-- Name: nhan_khau; Type: TABLE; Schema: nm_ccnpm; Owner: postgres
--

CREATE TABLE nm_ccnpm.nhan_khau (
    "ID" integer NOT NULL,
    "hoTen" character varying(100) NOT NULL,
    "bietDanh" character varying(100) NOT NULL,
    "namSinh" date NOT NULL,
    "gioiTinh" character varying(50) NOT NULL,
    "noiSinh" character varying(100) NOT NULL,
    "nguyenQuan" character varying(100) NOT NULL,
    "danToc" character varying(100) NOT NULL,
    "tonGiao" character varying(100) NOT NULL,
    "quocTich" character varying(100) NOT NULL,
    "soHoChieu" character varying(100) NOT NULL,
    "diaChiHienNay" character varying(100) NOT NULL,
    "trinhDoHocVan" character varying(100) NOT NULL,
    "trinhDoChuyenMon" character varying(100) NOT NULL,
    "bietTiengDanToc" character varying(100) NOT NULL,
    "trinhDoNgoaiNgu" character varying(100) NOT NULL,
    "ngheNghiep" character varying(100) NOT NULL,
    "noiLamViec" character varying(100) NOT NULL,
    "tienAn" character varying(100) NOT NULL,
    "ngayChuyenDen" date NOT NULL,
    "lyDoChuyenDen" character varying(100) NOT NULL,
    "ngayChuyenDi" date NOT NULL,
    "lyDoChuyenDi" character varying(100) NOT NULL,
    "diaChiMoi" character varying(100) NOT NULL,
    "ngayTao" date NOT NULL,
    "idNguoiTao" integer NOT NULL,
    "ngayXoa" date,
    "idNguoiXoa" integer,
    "lyDoXoa" character varying(100),
    ghichu character varying(100),
    "daXoa" boolean DEFAULT true NOT NULL,
    "noiThuongTru" character varying(100) NOT NULL,
    "maNhanKhau" character varying(30) NOT NULL
);


ALTER TABLE nm_ccnpm.nhan_khau OWNER TO postgres;

--
-- Name: nhan_khau_ID_seq; Type: SEQUENCE; Schema: nm_ccnpm; Owner: postgres
--

CREATE SEQUENCE nm_ccnpm."nhan_khau_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE nm_ccnpm."nhan_khau_ID_seq" OWNER TO postgres;

--
-- Name: nhan_khau_ID_seq; Type: SEQUENCE OWNED BY; Schema: nm_ccnpm; Owner: postgres
--

ALTER SEQUENCE nm_ccnpm."nhan_khau_ID_seq" OWNED BY nm_ccnpm.nhan_khau."ID";


--
-- Name: tam_tru; Type: TABLE; Schema: nm_ccnpm; Owner: postgres
--

CREATE TABLE nm_ccnpm.tam_tru (
    "ID" integer NOT NULL,
    "maGiayTamTru" character varying(100) NOT NULL,
    "soDienThoaiNguoiDangKy" character varying(100) NOT NULL,
    "tuNgay" date NOT NULL,
    "denNgay" date NOT NULL,
    "lyDo" character varying(100) NOT NULL,
    "idNhanKhau" integer NOT NULL
);


ALTER TABLE nm_ccnpm.tam_tru OWNER TO postgres;

--
-- Name: tam_tru_ID_seq; Type: SEQUENCE; Schema: nm_ccnpm; Owner: postgres
--

CREATE SEQUENCE nm_ccnpm."tam_tru_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE nm_ccnpm."tam_tru_ID_seq" OWNER TO postgres;

--
-- Name: tam_tru_ID_seq; Type: SEQUENCE OWNED BY; Schema: nm_ccnpm; Owner: postgres
--

ALTER SEQUENCE nm_ccnpm."tam_tru_ID_seq" OWNED BY nm_ccnpm.tam_tru."ID";


--
-- Name: tam_vang; Type: TABLE; Schema: nm_ccnpm; Owner: postgres
--

CREATE TABLE nm_ccnpm.tam_vang (
    "ID" integer NOT NULL,
    "idNhanKhau" integer NOT NULL,
    "maGiayTamVang" character varying NOT NULL,
    "noiTamTru" character varying NOT NULL,
    "tuNgay" date NOT NULL,
    "denNgay" date NOT NULL,
    "lyDo" character varying NOT NULL
);


ALTER TABLE nm_ccnpm.tam_vang OWNER TO postgres;

--
-- Name: tam_vang_ID_seq; Type: SEQUENCE; Schema: nm_ccnpm; Owner: postgres
--

CREATE SEQUENCE nm_ccnpm."tam_vang_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE nm_ccnpm."tam_vang_ID_seq" OWNER TO postgres;

--
-- Name: tam_vang_ID_seq; Type: SEQUENCE OWNED BY; Schema: nm_ccnpm; Owner: postgres
--

ALTER SEQUENCE nm_ccnpm."tam_vang_ID_seq" OWNED BY nm_ccnpm.tam_vang."ID";


--
-- Name: thanh_vien_cua_ho; Type: TABLE; Schema: nm_ccnpm; Owner: postgres
--

CREATE TABLE nm_ccnpm.thanh_vien_cua_ho (
    "idNhanKhau" integer NOT NULL,
    "idHoKhau" integer NOT NULL,
    "quanHeVoiChuHo" character varying(100) NOT NULL
);


ALTER TABLE nm_ccnpm.thanh_vien_cua_ho OWNER TO postgres;

--
-- Name: tieu_su; Type: TABLE; Schema: nm_ccnpm; Owner: postgres
--

CREATE TABLE nm_ccnpm.tieu_su (
    "ID" integer NOT NULL,
    "idNhanKhau" integer NOT NULL,
    "tuNgay" date NOT NULL,
    "denNgay" date NOT NULL,
    "diaChi" character varying(100) NOT NULL,
    "ngheNghiep" character varying(100) NOT NULL,
    "noiLamViec" character varying(100) NOT NULL
);


ALTER TABLE nm_ccnpm.tieu_su OWNER TO postgres;

--
-- Name: tieu_su_ID_seq; Type: SEQUENCE; Schema: nm_ccnpm; Owner: postgres
--

CREATE SEQUENCE nm_ccnpm."tieu_su_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE nm_ccnpm."tieu_su_ID_seq" OWNER TO postgres;

--
-- Name: tieu_su_ID_seq; Type: SEQUENCE OWNED BY; Schema: nm_ccnpm; Owner: postgres
--

ALTER SEQUENCE nm_ccnpm."tieu_su_ID_seq" OWNED BY nm_ccnpm.tieu_su."ID";


--
-- Name: user; Type: TABLE; Schema: nm_ccnpm; Owner: postgres
--

CREATE TABLE nm_ccnpm."user" (
    "ID" integer NOT NULL,
    username character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    role integer NOT NULL,
    date_created timestamp with time zone NOT NULL
);


ALTER TABLE nm_ccnpm."user" OWNER TO postgres;

--
-- Name: user_ID_seq; Type: SEQUENCE; Schema: nm_ccnpm; Owner: postgres
--

CREATE SEQUENCE nm_ccnpm."user_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE nm_ccnpm."user_ID_seq" OWNER TO postgres;

--
-- Name: user_ID_seq; Type: SEQUENCE OWNED BY; Schema: nm_ccnpm; Owner: postgres
--

ALTER SEQUENCE nm_ccnpm."user_ID_seq" OWNED BY nm_ccnpm."user"."ID";


--
-- Name: dinh_chinh ID; Type: DEFAULT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.dinh_chinh ALTER COLUMN "ID" SET DEFAULT nextval('nm_ccnpm."dinh_chinh_ID_seq"'::regclass);


--
-- Name: dinh_danh ID; Type: DEFAULT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.dinh_danh ALTER COLUMN "ID" SET DEFAULT nextval('nm_ccnpm."dinh_danh_ID_seq"'::regclass);


--
-- Name: dong_gop ID; Type: DEFAULT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.dong_gop ALTER COLUMN "ID" SET DEFAULT nextval('nm_ccnpm."dong_gop_ID_seq"'::regclass);


--
-- Name: ho_khau ID; Type: DEFAULT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.ho_khau ALTER COLUMN "ID" SET DEFAULT nextval('nm_ccnpm."ho_khau_ID_seq"'::regclass);


--
-- Name: khai_tu ID; Type: DEFAULT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.khai_tu ALTER COLUMN "ID" SET DEFAULT nextval('nm_ccnpm."khai_tu_ID_seq"'::regclass);


--
-- Name: nhan_khau ID; Type: DEFAULT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.nhan_khau ALTER COLUMN "ID" SET DEFAULT nextval('nm_ccnpm."nhan_khau_ID_seq"'::regclass);


--
-- Name: tam_tru ID; Type: DEFAULT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.tam_tru ALTER COLUMN "ID" SET DEFAULT nextval('nm_ccnpm."tam_tru_ID_seq"'::regclass);


--
-- Name: tam_vang ID; Type: DEFAULT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.tam_vang ALTER COLUMN "ID" SET DEFAULT nextval('nm_ccnpm."tam_vang_ID_seq"'::regclass);


--
-- Name: tieu_su ID; Type: DEFAULT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.tieu_su ALTER COLUMN "ID" SET DEFAULT nextval('nm_ccnpm."tieu_su_ID_seq"'::regclass);


--
-- Name: user ID; Type: DEFAULT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm."user" ALTER COLUMN "ID" SET DEFAULT nextval('nm_ccnpm."user_ID_seq"'::regclass);


--
-- Data for Name: dinh_chinh; Type: TABLE DATA; Schema: nm_ccnpm; Owner: postgres
--

COPY nm_ccnpm.dinh_chinh ("ID", "idHoKhau", "thongTinThayDoi", "thayDoiTu", "doiThanh", "ngayThayDoi", "nguoiThayDoi") FROM stdin;
\.
COPY nm_ccnpm.dinh_chinh ("ID", "idHoKhau", "thongTinThayDoi", "thayDoiTu", "doiThanh", "ngayThayDoi", "nguoiThayDoi") FROM '$$PATH$$/3470.dat';

--
-- Data for Name: dinh_danh; Type: TABLE DATA; Schema: nm_ccnpm; Owner: postgres
--

COPY nm_ccnpm.dinh_danh ("ID", "idNhanKhau", "soDinhDanh", "ngayCap", "noiCap", type) FROM stdin;
\.
COPY nm_ccnpm.dinh_danh ("ID", "idNhanKhau", "soDinhDanh", "ngayCap", "noiCap", type) FROM '$$PATH$$/3474.dat';

--
-- Data for Name: dong_gop; Type: TABLE DATA; Schema: nm_ccnpm; Owner: postgres
--

COPY nm_ccnpm.dong_gop ("ID", "tenKhoanDong", "ngayTao", "soTien", "donVi", "theLoai", "hoanThanh") FROM stdin;
\.
COPY nm_ccnpm.dong_gop ("ID", "tenKhoanDong", "ngayTao", "soTien", "donVi", "theLoai", "hoanThanh") FROM '$$PATH$$/3482.dat';

--
-- Data for Name: ho_khau; Type: TABLE DATA; Schema: nm_ccnpm; Owner: postgres
--

COPY nm_ccnpm.ho_khau ("ID", "idChuHo", "maKhuVuc", "diaChi", "ngayChuyenDi", "daXoa", "maHoKhau") FROM stdin;
\.
COPY nm_ccnpm.ho_khau ("ID", "idChuHo", "maKhuVuc", "diaChi", "ngayChuyenDi", "daXoa", "maHoKhau") FROM '$$PATH$$/3467.dat';

--
-- Data for Name: ho_khau_dong_gop; Type: TABLE DATA; Schema: nm_ccnpm; Owner: postgres
--

COPY nm_ccnpm.ho_khau_dong_gop ("idHoKhau", "daDong", "ngayDong", "idDongGop") FROM stdin;
\.
COPY nm_ccnpm.ho_khau_dong_gop ("idHoKhau", "daDong", "ngayDong", "idDongGop") FROM '$$PATH$$/3483.dat';

--
-- Data for Name: khai_tu; Type: TABLE DATA; Schema: nm_ccnpm; Owner: postgres
--

COPY nm_ccnpm.khai_tu ("ID", "soGiayKhaiTu", "idNguoiKhai", "idNguoiChet", "ngayKhai", "ngayChet", "lyDoChet") FROM stdin;
\.
COPY nm_ccnpm.khai_tu ("ID", "soGiayKhaiTu", "idNguoiKhai", "idNguoiChet", "ngayKhai", "ngayChet", "lyDoChet") FROM '$$PATH$$/3480.dat';

--
-- Data for Name: nhan_khau; Type: TABLE DATA; Schema: nm_ccnpm; Owner: postgres
--

COPY nm_ccnpm.nhan_khau ("ID", "hoTen", "bietDanh", "namSinh", "gioiTinh", "noiSinh", "nguyenQuan", "danToc", "tonGiao", "quocTich", "soHoChieu", "diaChiHienNay", "trinhDoHocVan", "trinhDoChuyenMon", "bietTiengDanToc", "trinhDoNgoaiNgu", "ngheNghiep", "noiLamViec", "tienAn", "ngayChuyenDen", "lyDoChuyenDen", "ngayChuyenDi", "lyDoChuyenDi", "diaChiMoi", "ngayTao", "idNguoiTao", "ngayXoa", "idNguoiXoa", "lyDoXoa", ghichu, "daXoa", "noiThuongTru", "maNhanKhau") FROM stdin;
\.
COPY nm_ccnpm.nhan_khau ("ID", "hoTen", "bietDanh", "namSinh", "gioiTinh", "noiSinh", "nguyenQuan", "danToc", "tonGiao", "quocTich", "soHoChieu", "diaChiHienNay", "trinhDoHocVan", "trinhDoChuyenMon", "bietTiengDanToc", "trinhDoNgoaiNgu", "ngheNghiep", "noiLamViec", "tienAn", "ngayChuyenDen", "lyDoChuyenDen", "ngayChuyenDi", "lyDoChuyenDi", "diaChiMoi", "ngayTao", "idNguoiTao", "ngayXoa", "idNguoiXoa", "lyDoXoa", ghichu, "daXoa", "noiThuongTru", "maNhanKhau") FROM '$$PATH$$/3463.dat';

--
-- Data for Name: tam_tru; Type: TABLE DATA; Schema: nm_ccnpm; Owner: postgres
--

COPY nm_ccnpm.tam_tru ("ID", "maGiayTamTru", "soDienThoaiNguoiDangKy", "tuNgay", "denNgay", "lyDo", "idNhanKhau") FROM stdin;
\.
COPY nm_ccnpm.tam_tru ("ID", "maGiayTamTru", "soDienThoaiNguoiDangKy", "tuNgay", "denNgay", "lyDo", "idNhanKhau") FROM '$$PATH$$/3476.dat';

--
-- Data for Name: tam_vang; Type: TABLE DATA; Schema: nm_ccnpm; Owner: postgres
--

COPY nm_ccnpm.tam_vang ("ID", "idNhanKhau", "maGiayTamVang", "noiTamTru", "tuNgay", "denNgay", "lyDo") FROM stdin;
\.
COPY nm_ccnpm.tam_vang ("ID", "idNhanKhau", "maGiayTamVang", "noiTamTru", "tuNgay", "denNgay", "lyDo") FROM '$$PATH$$/3478.dat';

--
-- Data for Name: thanh_vien_cua_ho; Type: TABLE DATA; Schema: nm_ccnpm; Owner: postgres
--

COPY nm_ccnpm.thanh_vien_cua_ho ("idNhanKhau", "idHoKhau", "quanHeVoiChuHo") FROM stdin;
\.
COPY nm_ccnpm.thanh_vien_cua_ho ("idNhanKhau", "idHoKhau", "quanHeVoiChuHo") FROM '$$PATH$$/3468.dat';

--
-- Data for Name: tieu_su; Type: TABLE DATA; Schema: nm_ccnpm; Owner: postgres
--

COPY nm_ccnpm.tieu_su ("ID", "idNhanKhau", "tuNgay", "denNgay", "diaChi", "ngheNghiep", "noiLamViec") FROM stdin;
\.
COPY nm_ccnpm.tieu_su ("ID", "idNhanKhau", "tuNgay", "denNgay", "diaChi", "ngheNghiep", "noiLamViec") FROM '$$PATH$$/3472.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: nm_ccnpm; Owner: postgres
--

COPY nm_ccnpm."user" ("ID", username, password, role, date_created) FROM stdin;
\.
COPY nm_ccnpm."user" ("ID", username, password, role, date_created) FROM '$$PATH$$/3465.dat';

--
-- Name: dinh_chinh_ID_seq; Type: SEQUENCE SET; Schema: nm_ccnpm; Owner: postgres
--

SELECT pg_catalog.setval('nm_ccnpm."dinh_chinh_ID_seq"', 105, true);


--
-- Name: dinh_danh_ID_seq; Type: SEQUENCE SET; Schema: nm_ccnpm; Owner: postgres
--

SELECT pg_catalog.setval('nm_ccnpm."dinh_danh_ID_seq"', 10, true);


--
-- Name: dong_gop_ID_seq; Type: SEQUENCE SET; Schema: nm_ccnpm; Owner: postgres
--

SELECT pg_catalog.setval('nm_ccnpm."dong_gop_ID_seq"', 4, true);


--
-- Name: ho_khau_ID_seq; Type: SEQUENCE SET; Schema: nm_ccnpm; Owner: postgres
--

SELECT pg_catalog.setval('nm_ccnpm."ho_khau_ID_seq"', 46, true);


--
-- Name: khai_tu_ID_seq; Type: SEQUENCE SET; Schema: nm_ccnpm; Owner: postgres
--

SELECT pg_catalog.setval('nm_ccnpm."khai_tu_ID_seq"', 17, true);


--
-- Name: nhan_khau_ID_seq; Type: SEQUENCE SET; Schema: nm_ccnpm; Owner: postgres
--

SELECT pg_catalog.setval('nm_ccnpm."nhan_khau_ID_seq"', 21, true);


--
-- Name: tam_tru_ID_seq; Type: SEQUENCE SET; Schema: nm_ccnpm; Owner: postgres
--

SELECT pg_catalog.setval('nm_ccnpm."tam_tru_ID_seq"', 4, true);


--
-- Name: tam_vang_ID_seq; Type: SEQUENCE SET; Schema: nm_ccnpm; Owner: postgres
--

SELECT pg_catalog.setval('nm_ccnpm."tam_vang_ID_seq"', 5, true);


--
-- Name: tieu_su_ID_seq; Type: SEQUENCE SET; Schema: nm_ccnpm; Owner: postgres
--

SELECT pg_catalog.setval('nm_ccnpm."tieu_su_ID_seq"', 12, true);


--
-- Name: user_ID_seq; Type: SEQUENCE SET; Schema: nm_ccnpm; Owner: postgres
--

SELECT pg_catalog.setval('nm_ccnpm."user_ID_seq"', 73, true);


--
-- Name: ho_khau_dong_gop 1 ho dong 1 lan; Type: CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.ho_khau_dong_gop
    ADD CONSTRAINT "1 ho dong 1 lan" UNIQUE ("idHoKhau", "idDongGop");


--
-- Name: thanh_vien_cua_ho 1 khau 1 ho; Type: CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.thanh_vien_cua_ho
    ADD CONSTRAINT "1 khau 1 ho" UNIQUE ("idNhanKhau", "idHoKhau");


--
-- Name: khai_tu 1 nhan khau; Type: CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.khai_tu
    ADD CONSTRAINT "1 nhan khau" UNIQUE ("idNguoiChet");


--
-- Name: thanh_vien_cua_ho 1 nhan khau 1 ho; Type: CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.thanh_vien_cua_ho
    ADD CONSTRAINT "1 nhan khau 1 ho" UNIQUE ("idNhanKhau");


--
-- Name: dinh_danh 1 nhan khau 1 sdd; Type: CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.dinh_danh
    ADD CONSTRAINT "1 nhan khau 1 sdd" UNIQUE ("idNhanKhau");


--
-- Name: dinh_chinh dinh_chinh_pkey; Type: CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.dinh_chinh
    ADD CONSTRAINT dinh_chinh_pkey PRIMARY KEY ("ID");


--
-- Name: dinh_danh dinh_danh_pkey; Type: CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.dinh_danh
    ADD CONSTRAINT dinh_danh_pkey PRIMARY KEY ("ID");


--
-- Name: dong_gop dong_gop_pkey; Type: CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.dong_gop
    ADD CONSTRAINT dong_gop_pkey PRIMARY KEY ("ID");


--
-- Name: ho_khau ho_khau_maHoKhau_key; Type: CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.ho_khau
    ADD CONSTRAINT "ho_khau_maHoKhau_key" UNIQUE ("maHoKhau");


--
-- Name: ho_khau ho_khau_pkey; Type: CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.ho_khau
    ADD CONSTRAINT ho_khau_pkey PRIMARY KEY ("ID");


--
-- Name: nhan_khau nhan_khau_pkey; Type: CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.nhan_khau
    ADD CONSTRAINT nhan_khau_pkey PRIMARY KEY ("ID");


--
-- Name: tam_tru tam_tru_pkey; Type: CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.tam_tru
    ADD CONSTRAINT tam_tru_pkey PRIMARY KEY ("ID");


--
-- Name: tam_vang tam_vang_pkey; Type: CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.tam_vang
    ADD CONSTRAINT tam_vang_pkey PRIMARY KEY ("ID");


--
-- Name: tieu_su tieu_su_pkey; Type: CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.tieu_su
    ADD CONSTRAINT tieu_su_pkey PRIMARY KEY ("ID");


--
-- Name: user unique username; Type: CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm."user"
    ADD CONSTRAINT "unique username" UNIQUE (username);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY ("ID");


--
-- Name: fki_id ho khau; Type: INDEX; Schema: nm_ccnpm; Owner: postgres
--

CREATE INDEX "fki_id ho khau" ON nm_ccnpm.dinh_chinh USING btree ("idHoKhau");


--
-- Name: fki_id nguoi chet; Type: INDEX; Schema: nm_ccnpm; Owner: postgres
--

CREATE INDEX "fki_id nguoi chet" ON nm_ccnpm.khai_tu USING btree ("idNguoiChet");


--
-- Name: fki_id nhan khau; Type: INDEX; Schema: nm_ccnpm; Owner: postgres
--

CREATE INDEX "fki_id nhan khau" ON nm_ccnpm.dinh_danh USING btree ("idNhanKhau");


--
-- Name: fki_id nk; Type: INDEX; Schema: nm_ccnpm; Owner: postgres
--

CREATE INDEX "fki_id nk" ON nm_ccnpm.tam_tru USING btree ("idNhanKhau");


--
-- Name: fki_nguoi khai; Type: INDEX; Schema: nm_ccnpm; Owner: postgres
--

CREATE INDEX "fki_nguoi khai" ON nm_ccnpm.khai_tu USING btree ("idNguoiKhai");


--
-- Name: fki_nhan khau; Type: INDEX; Schema: nm_ccnpm; Owner: postgres
--

CREATE INDEX "fki_nhan khau" ON nm_ccnpm.tam_vang USING btree ("idNhanKhau");


--
-- Name: fki_ref ho_khau; Type: INDEX; Schema: nm_ccnpm; Owner: postgres
--

CREATE INDEX "fki_ref ho_khau" ON nm_ccnpm.thanh_vien_cua_ho USING btree ("idHoKhau");


--
-- Name: fki_ref id chu ho; Type: INDEX; Schema: nm_ccnpm; Owner: postgres
--

CREATE INDEX "fki_ref id chu ho" ON nm_ccnpm.ho_khau USING btree ("idChuHo", "ID");


--
-- Name: fki_ref idChuHo-thanhVien Ho; Type: INDEX; Schema: nm_ccnpm; Owner: postgres
--

CREATE INDEX "fki_ref idChuHo-thanhVien Ho" ON nm_ccnpm.ho_khau USING btree ("idChuHo");


--
-- Name: fki_ref nguoi xoa; Type: INDEX; Schema: nm_ccnpm; Owner: postgres
--

CREATE INDEX "fki_ref nguoi xoa" ON nm_ccnpm.nhan_khau USING btree ("idNguoiXoa");


--
-- Name: fki_ref nhan_khau; Type: INDEX; Schema: nm_ccnpm; Owner: postgres
--

CREATE INDEX "fki_ref nhan_khau" ON nm_ccnpm.thanh_vien_cua_ho USING btree ("idNhanKhau");


--
-- Name: fki_ref nk; Type: INDEX; Schema: nm_ccnpm; Owner: postgres
--

CREATE INDEX "fki_ref nk" ON nm_ccnpm.tieu_su USING btree ("idNhanKhau");


--
-- Name: fki_ref user account; Type: INDEX; Schema: nm_ccnpm; Owner: postgres
--

CREATE INDEX "fki_ref user account" ON nm_ccnpm.nhan_khau USING btree ("idNguoiTao");


--
-- Name: fki_user thay doi; Type: INDEX; Schema: nm_ccnpm; Owner: postgres
--

CREATE INDEX "fki_user thay doi" ON nm_ccnpm.dinh_chinh USING btree ("nguoiThayDoi");


--
-- Name: khai_tu id nguoi chet; Type: FK CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.khai_tu
    ADD CONSTRAINT "id nguoi chet" FOREIGN KEY ("idNguoiChet") REFERENCES nm_ccnpm.nhan_khau("ID") NOT VALID;


--
-- Name: dinh_danh id nhan khau; Type: FK CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.dinh_danh
    ADD CONSTRAINT "id nhan khau" FOREIGN KEY ("idNhanKhau") REFERENCES nm_ccnpm.nhan_khau("ID") NOT VALID;


--
-- Name: tam_tru id nk; Type: FK CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.tam_tru
    ADD CONSTRAINT "id nk" FOREIGN KEY ("idNhanKhau") REFERENCES nm_ccnpm.nhan_khau("ID") NOT VALID;


--
-- Name: khai_tu nguoi khai; Type: FK CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.khai_tu
    ADD CONSTRAINT "nguoi khai" FOREIGN KEY ("idNguoiKhai") REFERENCES nm_ccnpm.nhan_khau("ID") NOT VALID;


--
-- Name: tam_vang nhan khau; Type: FK CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.tam_vang
    ADD CONSTRAINT "nhan khau" FOREIGN KEY ("idNhanKhau") REFERENCES nm_ccnpm.nhan_khau("ID") NOT VALID;


--
-- Name: thanh_vien_cua_ho re hokhau; Type: FK CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.thanh_vien_cua_ho
    ADD CONSTRAINT "re hokhau" FOREIGN KEY ("idHoKhau") REFERENCES nm_ccnpm.ho_khau("ID") ON DELETE CASCADE NOT VALID;


--
-- Name: ho_khau ref chu ho; Type: FK CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.ho_khau
    ADD CONSTRAINT "ref chu ho" FOREIGN KEY ("idChuHo") REFERENCES nm_ccnpm.thanh_vien_cua_ho("idNhanKhau") ON UPDATE SET NULL ON DELETE SET NULL NOT VALID;


--
-- Name: dinh_chinh ref ho khau; Type: FK CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.dinh_chinh
    ADD CONSTRAINT "ref ho khau" FOREIGN KEY ("idHoKhau") REFERENCES nm_ccnpm.ho_khau("ID") ON DELETE CASCADE NOT VALID;


--
-- Name: nhan_khau ref nguoi xoa; Type: FK CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.nhan_khau
    ADD CONSTRAINT "ref nguoi xoa" FOREIGN KEY ("idNguoiXoa") REFERENCES nm_ccnpm."user"("ID") ON DELETE SET NULL NOT VALID;


--
-- Name: thanh_vien_cua_ho ref nhan khau; Type: FK CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.thanh_vien_cua_ho
    ADD CONSTRAINT "ref nhan khau" FOREIGN KEY ("idNhanKhau") REFERENCES nm_ccnpm.nhan_khau("ID") ON DELETE CASCADE NOT VALID;


--
-- Name: tieu_su ref nk; Type: FK CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.tieu_su
    ADD CONSTRAINT "ref nk" FOREIGN KEY ("idNhanKhau") REFERENCES nm_ccnpm.nhan_khau("ID") ON DELETE CASCADE NOT VALID;


--
-- Name: nhan_khau ref user account; Type: FK CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.nhan_khau
    ADD CONSTRAINT "ref user account" FOREIGN KEY ("idNguoiTao") REFERENCES nm_ccnpm."user"("ID") ON DELETE SET NULL NOT VALID;


--
-- Name: dinh_chinh user thay doi; Type: FK CONSTRAINT; Schema: nm_ccnpm; Owner: postgres
--

ALTER TABLE ONLY nm_ccnpm.dinh_chinh
    ADD CONSTRAINT "user thay doi" FOREIGN KEY ("nguoiThayDoi") REFERENCES nm_ccnpm."user"("ID") NOT VALID;


--
-- PostgreSQL database dump complete
--

